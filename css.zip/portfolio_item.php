<?php
    require_once('database/PortfolioItem.php');

    // Obtain id
    $receivedId = $_GET['id'];
    $portfolioItem = PortfolioItem::findById($receivedId);
    require_once('partials/header.php');
?>

<body id="caseStudy">

    <div class="body-overlay"></div>
    <header class="header">
        <div class="headingOverlay"></div>
        <img class="caseStudyHeaderImg" src=" <?php echo $portfolioItem->getValue('heading_image_path'); ?>">
    </header>
    <section class="caseStudyOverview">
        <div class="textAndImageContainer">
            <div class="text">
                <h2><?php echo $portfolioItem->getValue('title'); ?></h2>
                <p class="standardCaseStudyText">
                    <?php echo $portfolioItem->getValue('entry_text'); ?>
                </p>
            </div>
            <div class="image">
                <img src="<?php echo $portfolioItem->getValue('overview_image'); ?>">
            </div>
        </div>
    </section>
    <section class="product">
        <div class="headerAndText">
            <h2 class="productHeader">The Product</h2>
            <p class="productText standardCaseStudyText" >
                <?php echo $portfolioItem->getValue('detail_text'); ?>
            </p>
        </div>
        <?php
            $images =  json_decode($portfolioItem->getValue('detail_images'));
        ?>

        <img class="productImage" src="<?php echo $images[0]; ?>">
        <img class="productImage" src="<?php echo $images[1]; ?>">

    </section>
    <section class="sources">
        <div>
            View the Code
        </div>
        <div>
            View a Live Demo
        </div>
    </section>
    <footer class="footer">
        <img src="img/logo.png" alt="Logo" class="footer__logo">
    </footer>

</body>
</html>