




function smoothScroll(target, duration) {
    var target = document.querySelector(target);
    var targetPosition = target.getBoundingClientRect().top - 100;
    var startingPosition = window.pageYOffset;
    var distance = targetPosition - startingPosition;
    var startTime = null;

    function animation(currentTime) {
        if (startTime == null) {
            startTime = currentTime;
        }

        var timeElapsed = currentTime - startTime;
        //var run = ease(timeElapsed, startingPosition, distance, duration);
        var run = ease(timeElapsed, startingPosition, targetPosition, duration);
        window.scrollTo(0, run);

        if (timeElapsed < duration) {
            requestAnimationFrame(animation);
        }
    }


    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) {
            return c / 2 * t * t + b;
        }
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(animation);

}

function setNavOpacity() {
    const scrollPosition = window.scrollY;

    // Next get the client height
    const clientHeight = document.documentElement.clientHeight;

    // Get the % of the first section scrolled past.
    const percent = scrollPosition / clientHeight;
    const percentOfDesiredValue = 1 * percent;

    if (percent <= 1) {
        const bodyOverlay = document.querySelector('.navOverlay');
        bodyOverlay.style.opacity = percentOfDesiredValue;
    } else {
        const bodyOverlay = document.querySelector('.navOverlay');
        bodyOverlay.style.opacity = 1;
    }

}

function setBackgroundOpacity() {
    const scrollPosition = window.scrollY;

    // Next get the client height
    const clientHeight = document.documentElement.clientHeight;

    // Get the % of the first section scrolled past.
    const percent = scrollPosition / clientHeight;
    const percentOfDesiredValue = 0.4 * percent;

    if (percent <= 1) {
        const bodyOverlay = document.querySelector('.body-overlay');
        bodyOverlay.style.opacity = percentOfDesiredValue;
    } else {
        const bodyOverlay = document.querySelector('.body-overlay');
        bodyOverlay.style.opacity = 0.4;
    }
}


document.addEventListener('scroll', function(evt) {
    setBackgroundOpacity();
    setNavOpacity();




});

// Wait for elements to load before adding event handlers...
document.addEventListener('DOMContentLoaded', () => {
    setBackgroundOpacity();

    document.querySelector('#menuItemPortfolio').addEventListener('click', function(evt) {
        evt.preventDefault();
        smoothScroll('.portfolio', 1000);
    });

    document.querySelector('#learnMore').addEventListener('click', function(evt) {
        evt.preventDefault();
        smoothScroll('.portfolio', 1000);
    });

    document.querySelector('#menuItemAbout').addEventListener('click', function(evt) {
        evt.preventDefault();
        smoothScroll('.about', 1000);
    });

    document.querySelector('#menuItemServices').addEventListener('click', function(evt) {
        evt.preventDefault();
        smoothScroll('.servicesContainer', 1000);
    });


    document.querySelector('#menuItemContact').addEventListener('click', function(evt) {
        evt.preventDefault();
        smoothScroll('.contact', 1000);
    });

    if (document.querySelector('.hamburger') !== null) {
        document.querySelector('.hamburger').addEventListener('click', function(evt) {
            this.classList.toggle('isActive');
        });
    }
    



}, false);