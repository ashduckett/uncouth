<?php
    define("TBL_PORTFOLIO_ITEM", "portfolio_item");




